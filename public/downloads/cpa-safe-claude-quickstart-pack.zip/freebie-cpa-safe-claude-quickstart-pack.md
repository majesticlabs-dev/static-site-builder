# CPA-Safe Claude Quickstart Pack

## What this free pack is
A small, practical starter pack for solo CPAs and small CPA firms that want to use Claude during busy season without acting reckless.

This is for drafting, organizing, summarizing, and cleanup work.
Not for final technical judgment.
Not for blind client-facing output.

**Core rule:** Claude is a junior coworker, not a tax authority.

---

## How to use this pack
1. Pick one low-risk workflow.
2. Use one prompt with sanitized inputs.
3. Review the output like a professional adult.
4. Keep what helps. Fix what’s weak. Never send blindly.

Best beginner use cases:
- draft a client follow-up
- rewrite a technical explanation into plain English
- turn rough notes into a recap
- turn messy comments into a task list

---

## The 7 prompts

### 1. Draft a client reply
```text
You are helping draft a client email for a CPA firm. Write a reply that is clear, calm, concise, and professional without sounding stiff.

Context:
- Client question: [paste sanitized summary]
- What we know so far: [facts]
- What we need from the client: [items]
- Tone: [firm tone]

Requirements:
- do not invent facts
- if something is uncertain, say so plainly
- keep the email easy to skim
- end with clear next steps

Draft the email.
```

### 2. Missing-doc request email
```text
Draft a friendly but direct missing-documents email for a CPA firm.

Client situation:
[summary]

Missing items:
[list]

Requirements:
- make the list easy to scan
- explain why we need the items in plain English
- include a deadline if provided: [date]
- keep it polite but not mushy

Write the email.
```

### 3. Rewrite technical explanation into plain English
```text
Rewrite the following explanation into plain English for a client who is smart but not a tax professional.

Original explanation:
[paste text]

Requirements:
- preserve meaning
- remove jargon where possible
- do not overpromise
- if there are uncertainties or assumptions, keep them visible
```

### 4. Turn call notes into a client-ready recap
```text
Turn these rough notes into a clean client recap email.

Notes:
[paste notes]

Requirements:
- organize by topic
- include decisions, open items, and next steps
- remove repetition and filler
- flag anything that sounds uncertain instead of pretending it is settled
```

### 5. Turn call notes into an internal action list
```text
Convert these notes into an internal task list for a CPA team.

Notes:
[paste notes]

Format:
- action item
- owner if obvious
- priority
- missing information needed

Do not invent owners or facts if they are not in the notes.
```

### 6. Turn review comments into a preparer to-do list
```text
Convert these review comments into a clean preparer to-do list.

Comments:
[paste comments]

Format:
- issue
- requested action
- priority
- dependencies or questions

Group similar comments together.
```

### 7. Triage an incoming client message
```text
Analyze this incoming client message and help me process it.

Message:
[paste sanitized message]

Return:
- what the client is asking
- urgency level
- missing facts
- recommended reply structure
- internal follow-up items if any

Do not draft a final answer unless requested.
```

---

## One-page human review checklist
Before anything gets sent, ask:

### Accuracy
- Did Claude invent any facts?
- Did it sound more certain than the facts support?
- Are dates, numbers, names, and next steps correct?

### Risk
- Did I paste anything I should not have pasted?
- Should this have been anonymized more aggressively?
- Is this a task Claude should help draft, but not decide?

### Clarity
- Is the output actually easy to understand?
- Is anything vague, awkward, or too wordy?
- Does it sound like my firm, not like a robot at a networking event?

### Client safety
- Would I be comfortable having this quoted back to me later?
- Does it avoid unsupported conclusions?
- Does it make next steps clear?

### Final check
- Did a human review this before it leaves the building?

If the answer is no, stop there.

---

## Guardrails

### Green-light use cases
Good uses for Claude:
- drafting emails
- summarizing notes
- organizing action items
- rewriting for clarity
- creating first-pass internal drafts

### Yellow-light use cases
Use carefully, with tighter review:
- issue framing
- memo structure
- notice-response prep
- internal summaries involving incomplete facts

### Red-light use cases
Do not trust Claude to do these alone:
- final technical conclusions
- final client advice without review
- anything requiring legal/tax authority it has not actually been given
- anything where fake certainty could create real damage

---

## What not to paste casually
Avoid dumping in:
- sensitive client personal data
- full tax return details
- credentials or access information
- anything you would hate to discover was handled carelessly

When possible:
- sanitize names
- remove IDs and account numbers
- summarize facts instead of pasting raw material

---

## The upgrade path
If this free pack helps, the paid product is the full version:

**Claude Cowork for CPAs: Busy-Season Workflow Kit**

That includes:
- 25 prompts
- full workflow playbook
- CPA-safe usage rules
- red / yellow / green guide
- review layer
- one-hour rollout plan
- bonus templates

The free pack gives you a few clean wins.
The paid kit gives you the whole operating system.

---

## Final line
Use Claude like a junior coworker. Not a liability.
