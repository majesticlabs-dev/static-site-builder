# Human Review Checklist
## Claude Cowork for CPAs

**Run this before anything leaves your desk.**

Use the checklist that matches what you're reviewing. You do not need to use all sections for every output — pick the right one.

---

## Quick check (any output, 60 seconds)

Before doing anything with a Claude output, confirm:

- [ ] I read the entire output, not just skimmed it
- [ ] Everything in the output traces back to something I provided
- [ ] Nothing was invented by Claude that I cannot verify
- [ ] The tone is appropriate for the audience
- [ ] I am comfortable signing my name to this

If any box is unchecked, fix it before using the output.

---

## Factual Verification Checklist

Use this for any output that contains facts, figures, or claims.

- [ ] Every factual claim in the output was present in my input
- [ ] No dollar amounts were invented or approximated by Claude
- [ ] No dates were invented or assumed by Claude
- [ ] No names, entities, or relationships were added by Claude
- [ ] No regulatory citations, deadlines, or obligations appear that I did not provide
- [ ] If Claude stated a percentage, rate, or threshold — I verified it independently
- [ ] If Claude referenced a law, rule, or IRS guidance — I can confirm it is accurate

**Fail condition:** Any fact that cannot be traced to your input or verified independently must be removed before the output is used.

---

## Tone and Clarity Checklist

Use this for client-facing emails, memos, and communications.

- [ ] The tone is appropriate for this specific client relationship
- [ ] The language is clear and would not confuse a non-accountant
- [ ] Nothing in the email sounds like legal advice when it should not
- [ ] No hedging language was removed that should stay (e.g., "may," "generally," "subject to...")
- [ ] The call to action or next steps are clear and accurate
- [ ] The email is not longer than it needs to be
- [ ] I would be comfortable if the client forwarded this to their attorney

---

## Unsupported-Claim Check

Use this for any draft that contains assertions, recommendations, or positions.

Look for and flag these patterns:

**Overconfidence triggers — review these carefully:**
- "you will," "you must," "you are required to," "you cannot"
- "the IRS will," "they cannot," "this is not taxable"
- "you owe," "you do not owe"
- Any sentence that sounds like a conclusion without a cited source

**Hedging that was removed — add it back if needed:**
- "generally," "typically," "in most cases"
- "based on the information provided"
- "subject to review of the specific facts"
- "we recommend confirming with..."

- [ ] No assertions appear that exceed what the facts support
- [ ] Any legal or regulatory conclusions have been independently confirmed
- [ ] All appropriate hedging language is present where needed
- [ ] Nothing in the draft could be mistaken for official tax advice

---

## Client-Facing Final Review Checklist

Use before sending any email, letter, or memo to a client.

- [ ] I read this as if I were the client receiving it
- [ ] The client will understand what is being asked of them (if anything)
- [ ] The client will understand the next steps
- [ ] All deadlines referenced are accurate
- [ ] All figures referenced are accurate
- [ ] The tone represents our firm appropriately
- [ ] Nothing in this email would alarm or confuse the client unnecessarily
- [ ] There is nothing the client might rely on that I have not confirmed is correct
- [ ] If this email generates a follow-up question, I know how to answer it
- [ ] I am comfortable with this email becoming part of the client's file

---

## Internal-Use-Only Review Checklist

Use before sharing a Claude-generated memo, summary, or handoff note internally.

- [ ] The summary accurately reflects the current status of this file
- [ ] All action items are accurate and attributed correctly
- [ ] Open questions are complete — nothing important is missing
- [ ] The next team member can pick this up and understand where things stand
- [ ] Any facts used in the internal note are traceable to source documents or calls
- [ ] Nothing in this note overstates the confidence level of an open issue
- [ ] Any issue framing is clearly labeled as a draft, not a conclusion

---

## The rule behind all of it

Claude drafts fast. It also fills gaps by default.

**Your job is to close the gaps before the output goes anywhere.**

If you don't have time to run the checklist, you don't have time to use the output.

---

*This checklist is a working tool, not a legal compliance standard. Adapt it to your firm's review process.*
