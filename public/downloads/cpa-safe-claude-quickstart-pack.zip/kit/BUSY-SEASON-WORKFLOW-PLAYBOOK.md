# Busy-Season Workflow Playbook
## Claude Cowork for CPAs

**12 CPA workflows. Step-by-step. Copy the prompt, fill the brackets, review the output.**

---

## How to use this playbook

Each workflow includes:
- **What it does** — the output you get
- **What to input** — what you paste in
- **The prompt** — copy/paste ready
- **What to review** — before it goes anywhere

Sanitize inputs. Review outputs. That's the whole model.

---

## Workflow 1: Client Email Reply Draft

**What it does:** Turns your situation notes into a clean client email draft.

**What to input:** Client's question or concern (sanitized), your response facts, tone guidance, what you need from them next.

**The prompt:**
```
You are helping draft a client email for a CPA firm. Write a reply that is clear, calm, concise, and professional without sounding stiff.

Context:
- Client question or concern: [paste sanitized summary]
- What we know so far: [relevant facts]
- What we still need from the client: [list if any]
- Tone: [e.g., firm but warm / neutral / urgent]

Requirements:
- do not invent facts
- if something is uncertain, say so plainly
- keep the email easy to skim
- end with clear next steps

Draft the email.
```

**What to review:**
- Are all facts in the draft supported by what you gave Claude?
- Does the tone match your firm's voice?
- Are the next steps accurate?
- Is anything missing that the client needs to know?

---

## Workflow 2: Missing-Document Request Email

**What it does:** Drafts a polite, direct email requesting outstanding client documents.

**What to input:** A list of missing items, the deadline if applicable, any explanation needed.

**The prompt:**
```
Draft a friendly but direct missing-documents email for a CPA firm.

Client situation:
[brief sanitized summary]

Missing items:
[list each item]

Requirements:
- make the list easy to scan
- explain why we need each item in plain English
- include a deadline if provided: [date or "none"]
- keep it polite but not mushy

Write the email.
```

**What to review:**
- Is the list complete and accurate?
- Does the deadline match your actual deadline?
- Is the tone appropriate for this client relationship?

---

## Workflow 3: Meeting Recap Email

**What it does:** Turns rough call notes into a clean client-ready recap.

**What to input:** Your raw notes from the call — rough is fine.

**The prompt:**
```
Turn these rough notes into a clean client recap email.

Notes:
[paste your notes]

Requirements:
- organize by topic
- include decisions made, open items, and next steps
- remove repetition and filler
- flag anything that sounds uncertain instead of pretending it is settled
- keep it easy to skim
```

**What to review:**
- Does it match what was actually decided?
- Are the open items and next steps accurate and complete?
- Is there anything in the draft not in your notes? Remove it.

---

## Workflow 4: Phone Notes to Action List

**What it does:** Converts messy call notes into a prioritized internal task list.

**What to input:** Your raw notes. Names, initials, or [STAFF A]-style labels are fine.

**The prompt:**
```
Convert these notes into an internal action list for a CPA team.

Notes:
[paste notes]

Format:
- action item
- owner if obvious from the notes
- priority (high / medium / low)
- missing information still needed

Do not invent owners or facts if they are not in the notes.
```

**What to review:**
- Are any action items missing?
- Are priorities accurate given your actual workload?
- Did Claude invent any details? Remove them.

---

## Workflow 5: Technical-to-Plain-English Rewrite

**What it does:** Rewrites a technical tax or accounting explanation into language a client can understand.

**What to input:** Your internal explanation, draft, or technical summary.

**The prompt:**
```
Rewrite the following explanation into plain English for a client who is smart but not a tax professional.

Original explanation:
[paste text]

Requirements:
- preserve meaning
- remove jargon where possible
- do not oversimplify to the point of being wrong
- if there are uncertainties or assumptions, keep them visible
- do not add legal conclusions that are not in the original
```

**What to review:**
- Does the plain-English version preserve the technical accuracy?
- Did Claude remove any qualifications that need to stay?
- Is anything now stated more confidently than the original?

---

## Workflow 6: Internal Handoff Memo

**What it does:** Drafts a clean internal handoff note so the next person picks up without confusion.

**What to input:** Current status, work done, open questions, next steps.

**The prompt:**
```
Create a clean internal handoff memo for another team member.

Context:
- client/project: [sanitized label, e.g., "Client A — 1040"]
- current status: [brief summary]
- work completed: [list]
- open questions: [list]
- next recommended actions: [list]

Make it skimmable and useful. No filler.
```

**What to review:**
- Are the open questions complete?
- Is the status accurate?
- Will the next person actually have what they need?

---

## Workflow 7: Organizer Cleanup Summary

**What it does:** Reviews intake or organizer notes and produces a clean summary of what you have, what's missing, and what needs follow-up.

**What to input:** Organizer responses or intake notes (sanitized/anonymized).

**The prompt:**
```
Review the following organizer notes or intake information and produce a clean summary.

Input:
[paste sanitized notes]

Output sections:
- key facts captured
- items that appear missing or incomplete
- questions that need follow-up with the client
- possible inconsistencies to review manually

Do not assume facts that are not provided.
```

**What to review:**
- Are the gaps accurate?
- Are the follow-up questions complete?
- Does anything in the summary contradict your notes?

---

## Workflow 8: Review-Comment Cleanup

**What it does:** Converts reviewer comments into a clean, prioritized preparer to-do list.

**What to input:** The raw review comments (can be rough — notes, bullet points, whatever format they came in).

**The prompt:**
```
Convert these review comments into a clean preparer to-do list.

Comments:
[paste comments]

Format:
- issue identified
- requested action
- priority
- dependencies or open questions

Group similar comments together.
```

**What to review:**
- Are all comments captured?
- Are priorities aligned with what the reviewer actually flagged as high priority?
- Is anything marked resolved that still needs attention?

---

## Workflow 9: First-Pass Issue Summary

**What it does:** Drafts a structured internal summary of an issue before deeper research.

**What to input:** The facts (sanitized), the question you're trying to answer, relevant context.

**The prompt:**
```
Using the facts below, draft a first-pass issue summary for internal use.

Facts:
[paste sanitized facts]

Include:
- background
- key issue or question
- open questions that must be answered
- possible paths to analyze
- information still needed before a conclusion

Keep it structured and cautious. Do not reach conclusions not supported by the facts provided.
```

**What to review:**
- Is the framing accurate?
- Did Claude jump to any conclusions? Flag and remove them.
- Are the open questions complete?

---

## Workflow 10: Notice Response Structure Draft

**What it does:** Builds a structural outline for a notice or information request response — not the final response, just the framework.

**What to input:** Sanitized summary of the notice, the main issue, key facts.

**The prompt:**
```
Create a structured draft outline for responding to a notice or information request.

Context:
[paste sanitized summary]

Include:
- issue summary
- facts to confirm before responding
- documents likely needed
- response structure (sections to address)
- risks or weak points that need manual review before finalizing

Do not invent law or factual support. Flag anything that needs verification.
```

**What to review:**
- Is the structure complete for this type of notice?
- Did Claude assert any factual or legal conclusions? Remove them.
- Is the risk flagging thorough?

---

## Workflow 11: Meeting Agenda Prep

**What it does:** Builds a clean agenda from a few context notes.

**What to input:** Meeting purpose, key topics, decisions needed, any prep items.

**The prompt:**
```
Build a meeting agenda for a CPA client meeting.

Context:
[paste brief summary]

Include:
- objective of the meeting
- 5 to 7 agenda items
- prep questions to ask or review in advance
- decisions that need to be made by the end of the meeting

Keep it practical and scannable.
```

**What to review:**
- Are the agenda items in the right order?
- Is anything missing that you know needs to be covered?
- Do the prep questions match what you actually need to cover?

---

## Workflow 12: Post-Meeting Summary Draft

**What it does:** Turns post-meeting notes into a clean internal or client-facing summary.

**What to input:** Your raw notes from the meeting.

**The prompt:**
```
Draft a post-meeting summary from the notes below.

Notes:
[paste notes]

Include:
- key takeaways
- decisions made
- action items with owner if clear
- deadlines mentioned
- follow-up items still open

Keep it concise. Do not add information that was not in the notes.
```

**What to review:**
- Are all action items captured and attributed correctly?
- Are decisions accurately reflected?
- Is anything in the summary that you did not actually cover? Remove it.

---

## One rule for every workflow

**If Claude adds something you did not provide, remove it.**

Claude fills gaps by default. Your job is to close those gaps before the output goes anywhere.

---

*All outputs require human review. This playbook is a drafting tool, not a final product.*
