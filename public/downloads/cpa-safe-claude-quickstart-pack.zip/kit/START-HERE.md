# Start Here
## Claude Cowork for CPAs: Busy-Season Workflow Kit

---

## The model in one sentence

**Claude is a junior coworker, not a tax authority.**

It drafts. It organizes. It summarizes. It cleans up.
You review. You sign. You decide.

That is the entire operating model. Everything else follows from it.

---

## What Claude is good at in a CPA firm

These are safe, high-leverage starting points:

- First-draft client emails (replies, reminders, follow-ups)
- Rewriting technical language into plain English for clients
- Turning messy call notes into a clean action list or recap
- Drafting internal handoff memos
- Organizing organizer responses into a clean summary
- Turning review comments into a preparer to-do list
- Building a meeting agenda from a few notes
- Post-meeting summary drafts
- First-pass issue framing before research
- Notice response structure drafts

---

## What Claude should never do alone

Hard stops. Do not use Claude for these without full human authority over the final output:

- Tax advice to clients
- Final legal or compliance conclusions
- Anything that will be signed and sent without review
- Research conclusions framed as authoritative
- Any output that will stand without a licensed professional verifying it

If Claude sounds certain, that is not authorization. Check it anyway.

---

## The junior coworker model

Think of Claude as a smart new hire who:

- Can write fast and clean
- Needs to be reviewed before anything goes to clients
- Should never be the last person to touch something important
- Saves you time on first drafts, not final judgment

You would not send a first-year associate's draft to a client unchecked.
Same rule applies here.

---

## Red / Yellow / Green use cases

### Green — Use freely with review
These are low-risk, high-value starting points.

- Drafting client email replies from notes you provide
- Rewriting a technical explanation into plain English
- Turning raw meeting notes into a clean summary
- Building a meeting agenda from bullet points
- Drafting a missing-doc request email
- Creating an internal action list from a call recap

### Yellow — Use with care and clear review
These have higher output sensitivity. Always double-check facts and tone.

- First-pass issue summaries for internal use
- Organizer cleanup and gap-flagging
- Drafting a notice response structure (not the response itself)
- Technical summaries of tax updates
- Review-comment triage lists

### Red — Do not use without significant human authority
These require your professional judgment and licensing to stand behind.

- Tax conclusions presented to clients as advice
- Final memo language around specific positions
- Anything representing the firm's official technical stance
- Legal exposure language
- Client representations that will not be reviewed line by line

---

## How to get value without getting reckless

1. **Sanitize before you paste.** Remove real client names, EINs, SSNs, dollar amounts that identify the client, and specific filing details. Use labels like [CLIENT A] or [ENTITY].
2. **Review every output.** Claude sounds confident. That is its default mode. It is not the same as being correct.
3. **Use the review checklist** in this kit before anything client-facing leaves your desk.
4. **Start with one workflow.** Pick one from the Busy-Season Workflow Playbook. Get comfortable. Then expand.
5. **Set a firm standard.** Use the guardrails in this kit to create a shared team operating rule. Random experimentation by staff is how problems happen.

---

## What's in this kit

| File | What it is |
|------|-----------|
| `START-HERE.md` | This file |
| `BUSY-SEASON-WORKFLOW-PLAYBOOK.md` | 12 CPA workflows with step-by-step instructions |
| `PROMPT-VAULT.md` | 25+ copy/paste prompts, grouped by category |
| `CPA-SAFE-GUARDRAILS.md` | What not to paste, anonymization rules, prohibited uses |
| `HUMAN-REVIEW-CHECKLIST.md` | Checklist before anything goes to a client |
| `ONE-HOUR-ROLLOUT-GUIDE.md` | How to actually implement this in your firm |
| `templates/` | Bonus: pre-filled templates for common firm writing |

---

## The first thing to do

Read this file.
Then open the Busy-Season Workflow Playbook and pick two workflows you will run this week.
That's it. Don't try to use everything at once.

---

*This kit is not tax advice. All Claude outputs require human review by a licensed professional before use.*
