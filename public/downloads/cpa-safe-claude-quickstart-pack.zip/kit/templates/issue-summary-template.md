# Issue Summary Template
## Claude Cowork for CPAs

**Use for internal issue summaries before research, review, or escalation.**

This is an internal document. It is not tax advice. Do not share with clients.

---

## Issue Summary

**Matter:** [sanitized label or internal code]
**Date:** [date]
**Prepared by:** [name/role]
**Status:** Draft / In review / Finalized

---

### Background

[2–4 sentences. What is the situation? What brought this issue to your attention?]

---

### Key issue or question

[State the specific issue or question in one clear sentence.]

---

### Facts relevant to the issue

- [fact 1 — verified]
- [fact 2 — verified]
- [fact 3 — needs confirmation]
- [fact 4 — assumed, needs verification]

**Still needed:**
- [information not yet obtained]
- [document or confirmation required]

---

### Open questions

- [question 1 — who is responsible for answering]
- [question 2]
- [question 3]

---

### Possible paths to analyze

- [path 1 — brief description]
- [path 2 — brief description]
- [path 3 — brief description]

---

### Risks or uncertainties

- [risk 1 — what could go wrong or what is unclear]
- [risk 2]

---

### Conclusion / recommendation placeholder

**Do not fill in until research and facts are confirmed.**

[Leave blank or: "Pending resolution of open questions above."]

---

### Next steps

- [ ] [action 1] — owner: [name] — by [date]
- [ ] [action 2] — owner: [name] — by [date]
- [ ] [action 3] — owner: [name] — by [date]

---

## How to use with Claude

To draft a first-pass summary from notes, use this prompt:

```
Using the facts below, draft a first-pass issue summary for internal use.

Facts:
[paste sanitized facts]

Include:
- background
- key issue
- open questions
- possible paths to analyze
- information still needed

Keep it structured and cautious. Do not reach conclusions not supported by the facts provided.
```

Transfer the Claude output into this template. Review every section before distributing internally.

---

**Important:** This template is for internal drafting use only. Any conclusion entered here must be separately verified before being communicated to a client.
