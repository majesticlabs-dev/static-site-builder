# Busy-Season Fast Wins
## Claude Cowork for CPAs — Single-Page Quick Reference

---

## The 5 prompts to use first

### 1. Draft a client email reply
```
You are helping draft a client email for a CPA firm. Write a clear, professional reply.

Context:
- Client question: [sanitized summary]
- What we know: [facts]
- What we need from them: [items or "none"]
- Tone: [warm / neutral / direct]

Do not invent facts. End with clear next steps. Draft the email.
```

### 2. Turn messy notes into an action list
```
Convert these notes into an internal action list for a CPA team.

Notes:
[paste]

Format: action item / owner if obvious / priority / missing info needed.
Do not invent owners or facts.
```

### 3. Rewrite something into plain English
```
Rewrite the following explanation into plain English for a smart non-accountant.

Text:
[paste]

Preserve meaning. Keep qualifications visible. Don't add confidence that isn't there.
```

### 4. Turn call notes into a client recap
```
Turn these rough notes into a clean client recap email.

Notes:
[paste]

Include: decisions made, open items, next steps. Flag anything uncertain.
```

### 5. Draft a missing-documents email
```
Draft a direct, polite missing-documents email for a CPA firm.

Missing items: [list]
Deadline: [date or "none"]

Make the list scannable. Explain why each item is needed. Keep it professional.
```

---

## The safest beginner use cases

Start here. These are low-risk, immediately useful:

- Drafting and cleaning up client emails
- Turning rough call notes into recaps or action lists
- Rewriting technical content into plain English
- Drafting a missing-document request
- Building a meeting agenda

---

## The 3 rules that prevent most bad outcomes

**1. Sanitize before you paste.**
No real client names. No SSNs. No account numbers. Replace with [CLIENT A], [ENTITY], [AMOUNT].

**2. Read every output.**
Claude sounds confident by default. Confidence is not accuracy. Check every fact before you use it.

**3. You are the signer.**
Claude drafts. You review. You sign. Never send anything you have not read and approved.

---

*Claude is a junior coworker. Not a tax authority. Use it to draft, organize, and summarize. Review everything. Sign nothing you haven't read.*
