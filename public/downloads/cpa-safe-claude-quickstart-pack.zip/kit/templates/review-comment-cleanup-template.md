# Review Comment Cleanup Template
## Claude Cowork for CPAs

**Use this when review comments need to be turned into a clear preparer to-do list.**

---

## Preparer To-Do List

**File/Matter:** [sanitized label]
**Review by:** [reviewer name or role]
**Review date:** [date]
**Preparer:** [name]

---

| # | Issue | Requested action | Priority | Dependencies / questions |
|---|-------|-----------------|----------|--------------------------|
| 1 | [issue from comment] | [what needs to be done] | High / Med / Low | [anything needed before this can be resolved] |
| 2 | | | | |
| 3 | | | | |
| 4 | | | | |
| 5 | | | | |

---

## Grouped by category (optional, use for complex reviews)

### Factual corrections
- [ ] [item] — [action needed]
- [ ] [item] — [action needed]

### Open questions to resolve
- [ ] [item] — [who needs to answer]
- [ ] [item] — [who needs to answer]

### Formatting or presentation
- [ ] [item] — [action needed]

### Items to escalate
- [ ] [item] — [what decision is needed and from whom]

---

## How to use with Claude

Use this prompt on raw review comments:

```
Convert these review comments into a clean preparer to-do list.

Comments:
[paste comments]

Format:
- issue identified
- requested action
- priority
- dependencies or open questions

Group similar comments together.
```

Then transfer the output into this template. Confirm priorities match what the reviewer actually intended.

---

## Review the output before using it

- [ ] All original comments are represented
- [ ] Nothing was misclassified in priority
- [ ] Dependencies are accurate
- [ ] Escalation items are flagged correctly

---

*Verify this list against the original review comments before distributing to the preparer.*
