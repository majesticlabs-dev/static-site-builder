# Client Email Templates
## Claude Cowork for CPAs

**How to use:** These are ready-to-fill structures. Replace brackets with real content, review, and send. You can also paste these into Claude with your specific details to get a fully drafted version.

---

## Template 1: Standard client reply

**Use for:** Routine reply to a client question or concern.

```
Subject: Re: [topic]

Hi [first name],

Thanks for reaching out.

[Core response — 2–4 sentences. State the answer or next step directly.]

[If you need something from them:]
To move forward, we need:
- [item 1]
- [item 2]

Please send these by [date] and we can [outcome].

If you have questions before then, feel free to reach out.

[Signature]
```

---

## Template 2: Missing documents request

**Use for:** When a client has not provided required documents and you need them.

```
Subject: Documents needed — [matter/year]

Hi [first name],

We're making progress on your [return/engagement] and need a few outstanding items to continue.

Still needed:
- [document 1] — needed for [reason in plain English]
- [document 2] — needed for [reason in plain English]
- [document 3] — needed for [reason in plain English]

Please send these by [deadline]. [Consequence of delay if applicable — one plain sentence.]

[Upload instructions or preferred method]

Let us know if you have any questions.

[Signature]
```

---

## Template 3: Deadline reminder

**Use for:** Reminding a client of an upcoming deadline.

```
Subject: Reminder: [deadline description]

Hi [first name],

Quick reminder: [deadline description] is coming up on [date].

[What the client needs to do — one clear sentence or short list]

If we don't receive [items] by [date], [consequence — stated plainly, not alarmist].

Please send [what you need] to [method] as soon as possible.

Let us know if you have questions.

[Signature]
```

---

## Template 4: "Here's what happens next" update

**Use for:** Setting expectations after a meeting, call, or engagement milestone.

```
Subject: Next steps — [matter]

Hi [first name],

Following up from our [call/meeting/review of your documents].

Here's where things stand:

What we're doing now:
- [action 1]
- [action 2]

What we need from you:
- [item 1 — by date if applicable]
- [item 2 — by date if applicable]

What happens after that:
[One or two sentences on what comes next once the above is done.]

Expected timeline: [rough estimate or "we'll update you by [date]"]

Feel free to reach out with questions.

[Signature]
```

---

## Template 5: Follow-up after no response

**Use for:** When a client has not replied and you need a response.

```
Subject: Following up — [matter]

Hi [first name],

I wanted to follow up on my message from [date]. We're still waiting on [what you need] to move forward with [what you're working on].

[If there's a hard deadline:]
To avoid [consequence], we need these by [date].

Please reply or send to [method] at your earliest convenience.

[Signature]
```

---

## Template 6: Technical explanation email

**Use for:** Explaining a tax or accounting issue to a non-accountant client.

```
Subject: Re: [topic]

Hi [first name],

[Brief plain-English explanation — 3–5 sentences max. State the situation, what it means, and what they need to know.]

[If there's a qualification or uncertainty:]
One thing to keep in mind: [qualification stated plainly].

[Next steps if any:]
From here, we [action]. You don't need to do anything at this point / Please [action].

Let us know if you'd like to talk through this.

[Signature]
```

---

## When to use Claude to fill these in

Paste any template above into Claude with this instruction:

```
Fill in this email template using the details below. Do not add information that is not in the details. Keep the tone [match existing / slightly warmer / more direct].

Template:
[paste template]

Details:
[paste your notes]
```

Then run the output through the quick checklist in `HUMAN-REVIEW-CHECKLIST.md` before sending.

---

*All templates require human review before sending. These are drafting aids, not final documents.*
