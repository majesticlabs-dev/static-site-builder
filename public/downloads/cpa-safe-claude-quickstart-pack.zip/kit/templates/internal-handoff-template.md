# Internal Handoff Template
## Claude Cowork for CPAs

**Use this when handing off a file, client matter, or task to another team member.**

Fill in the brackets. Remove any section that doesn't apply. Review before sharing internally.

---

## Handoff Note

**Client/Matter:** [sanitized label or internal code]
**Date of handoff:** [date]
**Handing off from:** [name or role]
**Picking up:** [name or role]

---

### Current status
[2–3 sentences. Where does this stand right now? What was last completed?]

---

### Work completed
- [completed item 1]
- [completed item 2]
- [completed item 3]

---

### Open items
- [ ] [action still needed — who owns it if known]
- [ ] [action still needed]
- [ ] [action still needed]

---

### Open questions
- [question 1 — what information or decision is still needed?]
- [question 2]

---

### Recommended next actions
1. [first thing to do]
2. [second thing to do]
3. [third thing to do if applicable]

---

### Key dates or deadlines
- [date] — [what's due or expected]
- [date] — [what's due or expected]

---

### Documents or files
- [location of key documents or files, if applicable]

---

### Anything else the next person needs to know
[Optional — any context that doesn't fit above. Keep it short.]

---

## How to use with Claude

To draft a handoff memo from rough notes, use this prompt:

```
Create a clean internal handoff memo for another team member.

Context:
- client/project: [sanitized label]
- current status: [summary]
- work completed: [list]
- open questions: [list]
- next recommended actions: [list]

Make it skimmable and useful.
```

Then format the output into this template before sharing.

---

*Review before sharing. All handoff notes should reflect the actual current state of the file.*
