# Meeting Recap Template
## Claude Cowork for CPAs

**Two versions: one for clients, one for internal use.**

Use whichever fits the meeting. Fill in the brackets, review, send.

---

## Version 1: Client-Facing Recap

**Subject line:** Meeting recap — [topic] — [date]

---

Hi [first name],

Thanks for meeting with us [today/on date].

Here's a brief recap.

**What we discussed:**
- [topic 1 — 1 sentence summary]
- [topic 2 — 1 sentence summary]
- [topic 3 — 1 sentence summary]

**Decisions made:**
- [decision 1]
- [decision 2]

**What we need from you:**
- [ ] [item 1] — by [date]
- [ ] [item 2] — by [date]

**What we're doing on our end:**
- [ ] [action 1] — by [date]
- [ ] [action 2] — by [date]

**Open items we'll follow up on:**
- [item 1 — who is following up]
- [item 2]

Let us know if anything needs clarification.

[Signature]

---

## Version 2: Internal Post-Meeting Note

**Meeting:** [topic]
**Date:** [date]
**Attendees:** [names or roles]

---

### Key takeaways
- [takeaway 1]
- [takeaway 2]
- [takeaway 3]

### Decisions made
- [decision 1]
- [decision 2]

### Action items
- [ ] [action] — owner: [name] — due: [date]
- [ ] [action] — owner: [name] — due: [date]
- [ ] [action] — owner: [name] — due: [date]

### Open questions
- [question 1 — who is responsible for resolving]
- [question 2]

### Follow-up needed from client
- [item 1] — expected by [date]
- [item 2]

### Notes
[Any additional context the team should know]

---

## How to use with Claude

Use this prompt to draft a recap from rough notes:

**For client-facing:**
```
Turn these rough notes into a clean client recap email.

Notes:
[paste your notes]

Requirements:
- organize by topic
- include decisions, open items, and next steps
- flag anything that sounds uncertain instead of presenting it as settled
```

**For internal:**
```
Draft a post-meeting summary from the notes below.

Notes:
[paste notes]

Include: key takeaways, decisions made, action items with owners if clear, deadlines mentioned, follow-up items still open.
```

Then format the Claude output into the relevant template. Run through the review checklist in `HUMAN-REVIEW-CHECKLIST.md` before sending the client version.

---

*Client-facing recaps require review before sending. Verify all action items and deadlines are accurate.*
