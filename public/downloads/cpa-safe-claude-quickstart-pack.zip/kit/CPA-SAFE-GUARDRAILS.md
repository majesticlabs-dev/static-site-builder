# CPA-Safe Guardrails
## Claude Cowork for CPAs

These are the operating rules. They are not optional.

---

## What not to paste into Claude

**Hard stops. Never paste these without anonymization:**

- Client names
- SSNs, EINs, ITINs
- Account numbers, routing numbers
- Specific dollar amounts that identify a client
- Exact addresses tied to a client
- Dates of birth
- Health information
- Any raw IRS notice with identifying information still in it
- Passwords, credentials, or portal access information

**Rule:** If pasting it into a Google Doc and accidentally sharing it would cause a client problem, anonymize it first.

---

## How to anonymize inputs

Replace real details with generic labels before pasting. This takes 60 seconds and removes the risk.

| Real data | Replace with |
|-----------|-------------|
| Client name | [CLIENT A] or [ENTITY] |
| SSN / EIN | [TAXPAYER ID] |
| Dollar amounts | [AMOUNT] or approximate range if essential |
| Specific address | [ADDRESS] |
| Specific dates | [DATE] or relative dates like "two months ago" |
| Account numbers | [ACCOUNT] |
| Employee name | [EMPLOYEE] |

**Example of bad input:**
```
John Smith, SSN 123-45-6789, owes $47,223 from his 2022 1040.
```

**Example of sanitized input:**
```
[CLIENT A] has an outstanding balance from their 2022 individual return.
The amount is in the five-figure range.
```

If Claude does not need the exact number to draft a useful email, do not give it the exact number.

---

## Anonymization rules by task type

### Client email drafting
- Use [CLIENT] instead of the name
- Use [DEADLINE] instead of exact dates if the prompt doesn't need them
- Use [AMOUNT DUE] instead of specific dollar figures
- Remove identifying account details

### Organizer or intake review
- Replace any PII before pasting
- Use [CLIENT A] and [ENTITY] throughout

### Issue framing and memo prep
- Remove all identifying client facts
- Use generic factual descriptions: "a closely held S-Corp" instead of the actual entity name
- Replace specific dollar figures with ranges

### Notice response drafting
- Remove notice number and client-specific details
- Use: "IRS CP2000-type notice" instead of the specific notice content

---

## Mandatory review rules

**These are not suggestions. They are requirements before any output is used.**

1. **Read the output.** Every word. Claude sounds confident. That is not the same as being accurate.

2. **Verify all facts.** Any fact in the output must trace to something you gave Claude. If it does not, remove it.

3. **Check conclusions.** If Claude asserts a tax position, conclusion, or legal point — verify or remove it. Claude does not have professional licensing. You do.

4. **Review tone.** Client-facing output should match your firm's voice. Edit accordingly.

5. **Remove overconfidence.** Words like "you will owe," "you are not required to," "the IRS cannot" should always trigger a second look before sending.

6. **Do not send before review.** If you do not have time to review it, you do not have time to use it.

---

## Prohibited uses

**Do not use Claude for these regardless of how good the output looks:**

- Final tax advice presented to clients as the firm's position
- Signing or certifying documents in any form
- Representing what the law "requires" without independent verification
- Any output that will not be read by a licensed professional before use
- Drafting client representations that won't be manually reviewed
- Automated sending of any AI-generated email without human approval
- Processing raw client data without sanitization first

---

## Red / Yellow / Green guide (quick reference)

### Green — Use with standard review

These are low-risk, high-value.

- Client email reply drafts from sanitized notes
- Plain-English rewrites of your own technical explanations
- Meeting agenda prep
- Post-meeting summary from your own notes
- Internal action lists
- Missing-document request emails
- Handoff memos from your own notes

### Yellow — Use with careful review

These require closer scrutiny before use.

- First-pass issue summaries
- Organizer cleanup and gap flagging
- Notice response structure outlines
- Technical alert summaries
- Review-comment triage

For all Yellow tasks:
- Double-check every factual claim
- Remove anything Claude added that was not in your input
- Have a second set of eyes on client-facing output

### Red — Do not use without complete manual authority over the output

- Final tax conclusions to clients
- Technical positions asserted as the firm's view
- Anything representing official advice on a tax position
- Client-facing language around penalties, liability, or legal obligation
- Anything a client might rely on without further professional consultation

---

## One rule that covers everything

**Claude is the draft. You are the signer.**

If you would not sign it, do not send it.
If you would not say it out loud to the client, do not write it down after Claude drafts it.

---

*This kit is not tax advice. These guardrails are operating guidance for a drafting tool, not a compliance program.*
