# Prompt Vault
## Claude Cowork for CPAs: 25+ Copy/Paste Prompts

**How to use:** Copy the prompt. Fill the brackets. Review the output. Do not send without reading it.

Sanitize client data before pasting. Every output is a draft.

---

## Category 1: Client Communication

### 1. Draft a client reply email
**Use for:** Clean first-draft replies to client questions or concerns.
**What to review:** Invented facts, overconfident tone, missing qualifications.

```
You are helping draft a client email for a CPA firm. Write a reply that is clear, calm, concise, and professional without sounding stiff.

Context:
- Client question: [paste sanitized summary]
- What we know so far: [facts]
- What we need from the client: [items or "none"]
- Tone: [firm tone, e.g., warm / neutral / urgent]

Requirements:
- do not invent facts
- if something is uncertain, say so plainly
- keep the email easy to skim
- end with clear next steps

Draft the email.
```

---

### 2. Missing-document request email
**Use for:** Chasing outstanding items without sounding passive or aggressive.
**What to review:** Accuracy of item list, deadline, tone.

```
Draft a friendly but direct missing-documents email for a CPA firm.

Client situation:
[brief summary]

Missing items:
[list]

Requirements:
- make the list easy to scan
- explain why we need each item in plain English
- include a deadline if provided: [date]
- keep it polite but not mushy

Write the email.
```

---

### 3. Deadline reminder email
**Use for:** Reminders with urgency but without pressure tactics.
**What to review:** Deadline accuracy, consequence accuracy.

```
Write a deadline reminder email for a tax client.

Details:
- upcoming deadline: [date]
- missing items or pending action: [details]
- consequence of delay: [details]

Requirements:
- concise
- no scare tactics
- clear call to action
- easy to skim on mobile
```

---

### 4. Rewrite technical explanation into plain English
**Use for:** Making a technical answer client-readable without dumbing it down into inaccuracy.
**What to review:** Did anything get oversimplified? Are qualifications still visible?

```
Rewrite the following explanation into plain English for a client who is smart but not a tax professional.

Original explanation:
[paste text]

Requirements:
- preserve meaning
- remove jargon where possible
- do not overpromise
- if there are uncertainties or assumptions, keep them visible
```

---

### 5. "Here's what happens next" email
**Use for:** Setting expectations after a meeting or engagement update.
**What to review:** Accuracy of timeline, client action items.

```
Draft an email that explains next steps in a tax or accounting process.

Context:
[summary]

Include:
- what we are doing now
- what the client needs to do
- what happens after that
- any timing expectations

Keep it calm, clear, and client-friendly.
```

---

### 6. Follow-up after no response
**Use for:** Second or third follow-up when the client has not replied.
**What to review:** Tone, accuracy of what's still outstanding.

```
Write a follow-up email to a client who has not responded.

Context:
- prior request: [summary]
- days since last message: [number]
- what we still need: [items]

Requirements:
- firm but not rude
- concise
- easy to scan
- include a direct next action
```

---

### 7. Triage an incoming client message
**Use for:** Processing and routing an incoming message before responding.
**What to review:** Classification accuracy. Do not send this to the client — it's internal.

```
Analyze this incoming client message and help me process it.

Message:
[paste sanitized message]

Return:
- what the client is asking
- urgency level
- missing facts needed to respond
- recommended reply structure
- internal follow-up items if any

Do not draft a final answer unless I ask.
```

---

## Category 2: Meetings, Notes, and Internal Ops

### 8. Turn call notes into a client-ready recap
**Use for:** Converting rough meeting or call notes into a structured client email.
**What to review:** Accuracy of decisions and action items. Remove anything not in your notes.

```
Turn these rough notes into a clean client recap email.

Notes:
[paste notes]

Requirements:
- organize by topic
- include decisions, open items, and next steps
- remove repetition and filler
- flag anything that sounds uncertain instead of presenting it as settled
```

---

### 9. Turn call notes into an internal action list
**Use for:** Post-call task triage for the team.
**What to review:** Ownership accuracy. Claude will guess — confirm or correct.

```
Convert these notes into an internal task list for a CPA team.

Notes:
[paste notes]

Format:
- action item
- owner if obvious from the notes
- priority
- missing information needed

Do not invent owners or facts if they are not in the notes.
```

---

### 10. Draft an internal handoff memo
**Use for:** Handing off a file or project to another team member.
**What to review:** Completeness of open questions, accuracy of status.

```
Create a clean internal handoff memo for another team member.

Context:
- client/project: [sanitized label]
- current status: [summary]
- work completed: [list]
- open questions: [list]
- next recommended actions: [list]

Make it skimmable and useful.
```

---

### 11. Create a meeting agenda
**Use for:** Prep before a client or internal meeting.
**What to review:** Are the right topics covered? Is anything missing?

```
Build a meeting agenda for a CPA client meeting.

Context:
[summary]

Include:
- objective of the meeting
- 5 to 7 agenda items
- prep questions to ask
- decisions needed by the end
```

---

### 12. Post-meeting summary draft
**Use for:** Capturing action items and decisions after a meeting.
**What to review:** Accuracy of decisions and attributed actions. Nothing invented.

```
Draft a post-meeting summary from the notes below.

Notes:
[paste notes]

Include:
- key takeaways
- action items
- deadlines mentioned
- follow-up items

Keep it concise and clean.
```

---

### 13. Organizer cleanup summary
**Use for:** Reviewing organizer responses before work begins.
**What to review:** Are the gaps accurate? Are follow-up questions the right ones?

```
Review the following organizer notes or intake information and produce a clean summary.

Input:
[paste sanitized notes]

Output sections:
- key facts captured
- items that appear missing
- questions that need follow-up
- possible inconsistencies to review manually

Do not assume facts that are not provided.
```

---

## Category 3: Review and QA

### 14. Turn review comments into a preparer to-do list
**Use for:** Cleaning up reviewer feedback into actionable steps.
**What to review:** Are all comments captured? Priorities match reviewer intent?

```
Convert these review comments into a clean preparer to-do list.

Comments:
[paste comments]

Format:
- issue
- requested action
- priority
- dependencies or questions

Group similar comments together.
```

---

### 15. Spot unsupported claims or weak language
**Use for:** Checking a draft for anything that sounds more certain than it should.
**What to review:** Do the flagged items actually need fixing? Is Claude's reasoning sound?

```
Review the draft below and flag any sentence that:
- makes a claim not supported by the provided facts
- sounds too certain given the context
- could confuse a client
- needs verification before being sent

Draft:
[paste draft]

Return:
- flagged text
- why it is risky
- suggested safer wording
```

---

### 16. Tighten a draft without changing meaning
**Use for:** Cleaning up wordy or stiff internal drafts.
**What to review:** Did anything get changed that needed to stay precise?

```
Edit this draft for clarity, concision, and professional tone.

Draft:
[paste text]

Requirements:
- preserve meaning
- reduce fluff
- improve readability
- do not add new facts
```

---

### 17. Build a review checklist for a specific deliverable
**Use for:** Creating a quick QA checklist before review.
**What to review:** Is anything missing from the checklist based on your firm's standards?

```
Create a short human review checklist for this draft deliverable.

Deliverable type: [email / memo / summary / internal note]
Context: [summary]

Checklist should focus on:
- factual accuracy
- missing assumptions
- tone
- clarity
- next steps
```

---

### 18. Compare source notes to draft output
**Use for:** Verifying that a Claude draft does not contradict or exceed your source material.
**What to review:** Flag everything Claude identifies. Do not send anything with unexplained gaps.

```
Compare the source notes with the draft and identify anything in the draft that is:
- missing from the source
- inconsistent with the source
- phrased more strongly than the source supports

Source notes:
[paste]

Draft:
[paste]
```

---

## Category 4: Issue Framing and Memo Prep

### 19. Frame an issue before research
**Use for:** Structuring a tax or accounting question before diving into research.
**What to review:** Is the framing accurate? Did Claude introduce any assumptions?

```
Help me frame a tax or accounting issue before deeper research.

Facts:
[paste sanitized facts]

Return:
- key facts that matter
- questions that must be answered
- assumptions that need confirmation
- a suggested structure for further research

Do not provide final conclusions unless directly supported by the facts provided.
```

---

### 20. Build a first-pass issue summary
**Use for:** Internal summaries before a supervisor review or research discussion.
**What to review:** No conclusions stated as settled. Open questions are complete.

```
Using the facts below, draft a first-pass issue summary for internal use.

Facts:
[paste]

Include:
- background
- key issue
- open questions
- possible paths to analyze
- information still needed

Keep it structured and cautious.
```

---

### 21. Draft a memo skeleton
**Use for:** Setting up the structure of a research or issue memo.
**What to review:** Is the structure appropriate for this memo type? Do not treat this as a filled-in analysis.

```
Create a memo outline for this issue.

Topic:
[summary]

Include sections for:
- facts
- issue
- authorities to review
- analysis points
- risks / uncertainties
- conclusion placeholder

Do not fill in legal or tax authority unless provided.
```

---

### 22. Summarize an article or update into decision points
**Use for:** Tax alerts, IRS updates, new guidance — turning them into actionable firm notes.
**What to review:** Accuracy against the original source. Do not rely solely on Claude's summary.

```
Summarize the following article, alert, or update into decision points for a CPA firm.

Text:
[paste text]

Return:
- what changed
- who it matters to
- practical implications
- follow-up questions for clients or staff
```

---

### 23. Draft a notice-response structure
**Use for:** Building the outline of a response to an IRS or state notice before drafting begins.
**What to review:** Did Claude assert any factual or legal conclusions? Remove them.

```
Create a structured draft outline for responding to a notice or information request.

Context:
[paste sanitized summary]

Include:
- issue summary
- facts to confirm before responding
- documents needed
- response structure
- risks or weak points to review manually before finalizing

Do not invent law or factual support.
```

---

## Category 5: Admin and Workflow Cleanup

### 24. Build a standard operating note from a repeated task
**Use for:** Documenting a repeated internal process so it does not live only in one person's head.
**What to review:** Is the SOP complete? Are the steps in the right order?

```
Turn this repeated task process into a short internal SOP.

Process notes:
[paste notes]

Format:
- purpose
- trigger
- steps
- common mistakes
- review points

Keep it practical and short.
```

---

### 25. Create a staff-ready checklist from a messy process
**Use for:** Taking a process description and making it usable for staff.
**What to review:** Are all steps included? Are manager approval points accurate?

```
Convert this process description into a checklist a staff member can follow.

Process:
[paste]

Requirements:
- logical order
- no fluff
- include review checkpoints
- flag steps that require manager approval
```

---

### 26. Reframe a client question into an internal work ticket
**Use for:** Converting a vague or complex client request into a specific task with clear inputs.
**What to review:** Is the scope of the ticket accurate?

```
Take this client question or request and convert it into a clear internal work ticket.

Client request:
[paste sanitized version]

Output:
- what is being asked
- what information we have
- what information we still need
- proposed scope of work
- estimated output type

Keep it concise.
```

---

### 27. Draft an issue summary from fragmented notes
**Use for:** Consolidating fragmented emails, notes, and calls into a coherent summary of what's happening on a file.
**What to review:** Are all open threads captured? Nothing invented.

```
Consolidate these fragmented notes and messages into a clean internal issue summary.

Notes:
[paste from multiple sources]

Output:
- current situation
- what has been done
- open questions
- recommended next actions

Do not add information not present in the notes.
```

---

## Use rule for every prompt

Never paste sensitive client data casually. Sanitize when needed. Review every output. If Claude sounds certain where it should be cautious, fix it before it goes anywhere.

---

*This vault is a drafting tool. All outputs require human review by a licensed professional before use.*
