# One-Hour Rollout Guide
## Claude Cowork for CPAs

**Goal: Get your firm actually using this — not just reading about it.**

This guide assumes you have one hour. You will not implement everything. That is fine. Momentum matters more than completeness.

---

## Before you start

- [ ] You have access to Claude (claude.ai or Claude via API/app)
- [ ] You have read `START-HERE.md`
- [ ] You have skimmed `CPA-SAFE-GUARDRAILS.md`
- [ ] You know which staff member will be your first tester

One hour. Real work. Let's go.

---

## Minutes 0–10: Who tests first

**Do not roll this out to everyone at once.**

Chaos happens when ten people start using AI differently with no shared method. Start with one person.

**Who should test first:**

Pick someone who:
- Already curious about AI (reduces resistance)
- Works on high-volume, repetitive writing (emails, recaps, handoffs)
- Is detail-oriented enough to actually review outputs
- Has direct access to you if something seems off

**Not a good first tester:**
- Anyone who would send AI-drafted output without reading it
- Anyone who will panic and escalate unnecessarily
- The most skeptical person on the team (let wins build first)

**Your action:** Name one person. Tell them they're piloting this for the first week. Get buy-in now.

---

## Minutes 10–25: Pick 3 workflows to start

Do not start with everything. Pick three workflows that match your busiest current pain.

**Recommended starting three for most firms:**

| Workflow | Why start here |
|----------|----------------|
| Client email reply draft | Immediate time save. Easy to review. Low risk. |
| Meeting recap cleanup | Obvious before/after. Staff loves it. |
| Turn review comments into a to-do list | Saves the preparer real time. Easy to validate. |

**How to pick yours:**

Ask: where is the most repetitive, draft-heavy work happening right now?

- High email volume? → Start with client communication workflows.
- Review bottlenecks? → Start with review-comment cleanup.
- Messy handoffs? → Start with internal handoff memo.

**Your action:** Circle three workflows in `BUSY-SEASON-WORKFLOW-PLAYBOOK.md`. Write them on a sticky note. Those are the only ones your tester runs this week.

---

## Minutes 25–40: Run one workflow right now

Do not just plan. Run a real prompt right now using a current piece of work.

**Steps:**

1. Pick one piece of work sitting on your desk (a draft email, call notes, review comments).
2. Sanitize the input using the guidelines in `CPA-SAFE-GUARDRAILS.md`.
3. Open Claude. Paste the prompt from `PROMPT-VAULT.md` or `BUSY-SEASON-WORKFLOW-PLAYBOOK.md`.
4. Fill in the brackets. Hit enter.
5. Read the output using the quick checklist from `HUMAN-REVIEW-CHECKLIST.md`.
6. Edit what needs editing.

**What you're proving:** That this is real, not theoretical.

**Your action:** Complete one full workflow before moving on. Time it. Note what surprised you.

---

## Minutes 40–50: Collect feedback after the first week

Before you leave this guide, set up a simple way to collect feedback from your tester.

**You need to know:**

- Which workflows saved real time?
- Which outputs needed the most editing?
- Were any inputs flagged as hard to sanitize?
- Did anything feel risky or off?
- What would make this easier to use?

**Simple method:** A 5-question Slack message or email at end of first week. Do not make it a form. Just ask.

**Your action:** Put a reminder in your calendar for 7 days from now: "Ask [tester name] for workflow feedback."

---

## Minutes 50–60: Set the firm standard

Once the pilot is done and feedback is in, you have what you need to set a shared standard.

**The standard should include:**

1. **Which workflows are approved for use** — start with your tested three.
2. **Anonymization rules** — use the guidelines in `CPA-SAFE-GUARDRAILS.md`.
3. **Review requirement** — every output gets reviewed before use. No exceptions.
4. **Who can expand usage** — only after demonstrating the review habit.
5. **What requires manager approval** — any new use case not already on the approved list.

**Why this matters:** Without a shared standard, staff will freelance. One person will start pasting raw client data. Another will send output without reading it. The standard is how you keep the upside without creating the downside.

**Your action:** Write the firm standard in one page or fewer. Post it where staff can see it. Use `CPA-SAFE-GUARDRAILS.md` as your source material.

---

## After week one: How to standardize

**Good signs your pilot worked:**
- The tester is using it daily without prompting
- Output quality is high enough that review is fast
- They are suggesting new use cases
- Review is happening consistently

**Warning signs:**
- The tester sends AI output to clients without reading it
- They start asking Claude for tax advice
- They skip sanitization because it feels slow
- They expand to new workflows without discussing it

**If warning signs appear:** Pull back to the three approved workflows and reinforce the review habit. Speed comes after the review discipline is in place.

---

## How to expand after week one

Add one or two new workflows per week. Do not add more than that.

**Expansion order (recommended):**

Week 1–2: Client email replies, meeting recaps, review-comment cleanup
Week 3–4: Organizer cleanup, internal handoffs, agenda prep
Week 5+: Issue framing, notice response structure, technical rewrites

Each time you add a workflow, run it yourself once before expanding to staff.

---

## One thing that will break this

**If staff starts using Claude without the review step, stop the rollout.**

Not for good. Just long enough to reinforce the habit.

The junior coworker model only works if the senior reviewer is actually reviewing.

---

*This guide covers rollout mechanics only. It is not tax advice and is not a compliance program.*
